# 제주 해커톤

제주 해커톤 프로그램과 관련된 자료를 보관하는 저장소입니다.

- 프로그램 소스와 실행 안내: [`제주 프로그램/`](제주%20프로그램/README.md)
- 대회별 문서 정리 기준: [`competitions/`](competitions/README.md)
- 프론트엔드 개발·검수: [`제주 프로그램/frontend/`](제주%20프로그램/frontend/README.md)
- [GitHub 업로드 안내](GITHUB_UPLOAD.md)
