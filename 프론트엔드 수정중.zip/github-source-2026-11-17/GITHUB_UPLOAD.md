# GitHub 업로드 안내

이 폴더는 Git 이력이 없는 소스 사본입니다. 기존 GitHub 저장소를 갱신할 때는 해당 저장소를 먼저 clone한 뒤 필요한 파일을 반영하고 diff를 검토하세요. 이 소스 묶음에는 기존 커밋 이력이 없습니다.

## 포함 범위

- 프로그램 소스, 테스트, 의존성 잠금 파일, 설정 예시와 문서
- `backend/app/data/`의 프로그램용 정류소·읍면동 목록
- 가상 매출 CSV와 프론트엔드 검수 화면
- Pretendard 글꼴 라이선스 (`frontend/public/licenses/`)

## 제외 범위

가상환경, `node_modules`, 빌드 결과물, EXE, 로컬 데이터베이스와 로그, 실제 `.env`, 로컬 수집 계획, 모델과 실행용 DLL, `runtime`의 가상 테스트 자료는 제외합니다. 실행 파일이 필요하면 별도로 빌드하고 GitHub Releases 같은 배포 경로에서 관리하세요.

원본 프로그램의 `backend/app/data/`와 로컬 사용자 저장소인 `제주 프로그램/data/`는 서로 다릅니다. 전자는 프로그램 실행에 필요한 목록이므로 유지합니다.

## 업로드 전 확인

기존 저장소의 작업 폴더에 반영한 다음 다음 명령으로 변경 파일을 확인합니다.

```powershell
git status --short
git diff --stat
git diff
```

확인한 변경 파일만 stage한 뒤 `git diff --cached --stat`와 `git diff --cached`로 검토하고 commit/push하세요. `.gitignore`는 이미 추적 중인 파일을 자동으로 제외하지 않으므로, 기존 저장소에서 추적 중인 데이터나 비밀 설정이 있는지도 확인해야 합니다.

## 개발 안내

- [프로젝트 실행 안내](제주%20프로그램/README.md)
- [프론트엔드 개발·검수 안내](제주%20프로그램/frontend/README.md)
- [현재 결산 화면 구성](제주%20프로그램/frontend/design/daily-comparison.md)

이번 정리는 프론트엔드 문서와 소스 배포 구성을 대상으로 했으며 백엔드 동작은 변경하지 않았습니다. GitHub 업로드와 원격 저장소 변경은 수행하지 않았습니다.
